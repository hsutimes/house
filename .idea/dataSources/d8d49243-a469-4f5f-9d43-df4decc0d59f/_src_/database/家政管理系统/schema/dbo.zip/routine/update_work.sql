CREATE PROCEDURE update_work(@id VARCHAR(32))
AS
  BEGIN
    DECLARE @w_id VARCHAR(32) = (SELECT o_work
                                 FROM [order]
                                 WHERE o_id = @id);
    DECLARE @count VARCHAR(32) = (SELECT w_count
                                  FROM work
                                  WHERE w_id = @w_id) + 1;
    UPDATE work
    SET w_count = @count
    WHERE w_id = @w_id;
  END
GO
