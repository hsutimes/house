CREATE VIEW [dbo].[orders] AS 
SELECT
dbo.[order].o_id,
dbo.[order].o_number,
dbo.[work].w_money,
dbo.[order].o_info,
dbo.[order].o_die,
dbo.[order].o_comment,
dbo.[user].u_name,
dbo.shop.s_name,
dbo.[order].o_master,
dbo.[work].w_info,
dbo.[order].create_time,
dbo.[order].modified_time,
dbo.[order].o_work,
dbo.[work].w_shop

FROM
	dbo.[order]
INNER JOIN dbo.[work] ON dbo.[order].o_work = dbo.[work].w_id
INNER JOIN dbo.[user] ON '' = ''
AND dbo.[work].w_user = dbo.[user].u_id
INNER JOIN dbo.shop ON '' = ''
AND dbo.[work].w_shop = dbo.shop.s_id
GO
