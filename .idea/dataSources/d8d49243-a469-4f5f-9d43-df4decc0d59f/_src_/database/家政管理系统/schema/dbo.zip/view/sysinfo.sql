CREATE VIEW sysinfo AS
  SELECT
    count(DISTINCT [user].u_id)      AS u_num,
    count(DISTINCT log.l_id)         AS l_num,
    count(DISTINCT [order].o_id)     AS o_num,
    count(DISTINCT server_type.t_id) AS t_num,
    count(DISTINCT shop.s_id)        AS s_num,
    count(DISTINCT work.w_id)        AS w_num
  FROM [user], log, [order], server_type, shop, work
GO
