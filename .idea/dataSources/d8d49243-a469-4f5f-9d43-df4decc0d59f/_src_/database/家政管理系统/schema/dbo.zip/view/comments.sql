CREATE VIEW [dbo].[comments] AS 
SELECT
	dbo.[order].o_id,
	dbo.[order].o_comment,
	dbo.[order].o_die,
	dbo.[work].w_user,
	dbo.[work].w_shop,
	dbo.[order].o_master,
	dbo.[order].create_time,
	dbo.[order].modified_time
FROM
	dbo.[order]
INNER JOIN dbo.[work] ON dbo.[order].o_work = dbo.[work].w_id
GO
