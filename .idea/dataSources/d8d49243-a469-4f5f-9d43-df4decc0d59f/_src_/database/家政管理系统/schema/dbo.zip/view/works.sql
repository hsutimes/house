CREATE VIEW works AS
SELECT w_id,[user].u_id,[user].u_name,[user].u_info,w_money,t_name,t_type,t_info FROM work,[user],server_type
WHERE w_user = [user].u_id AND w_server = server_type.t_id
GO
