CREATE VIEW labels AS
  SELECT
    l_id,
    s_name,
    s_info,
    t_name,
    t_info,
    t_type,
    shop.create_time,
    shop.modified_time
  FROM label, shop, server_type
  WHERE l_shop = s_id AND l_s_type = t_id
GO
